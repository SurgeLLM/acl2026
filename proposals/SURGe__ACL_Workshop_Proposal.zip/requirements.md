 https://www.aclweb.org/portal/content/eaclacl-2026-joint-call-workshops

The two pages for the main proposal must include:

A title, short name / acronym, and a brief description of the workshop topic and content.
Some conferences might take place only or partially virtually. We request submissions to contain a brief discussion on measures planned to make sure a workshop is successful and productive in case of a hybrid or virtual-only attendance.
A description of special requirements and technical needs.
A description of any limitations that would restrict the workshop to a specific venue (EACL or ACL). For example: if the workshop is compatible with only one of these events, logistically, thematically or otherwise, or if the workshop cannot be held at a venue for logistical reasons.
Diversity and Inclusion Efforts (see more details below)
If the workshop has been held before, a note specifying: how many prior editions occurred, where previous workshops were held, how many submissions the workshop received in the last iteration and how many papers were accepted (also specify if they were not regular papers, e.g., shared task system description papers), and an estimate of how many in-person posters the workshop attracted.
(Optional/If Known) A list of invited speakers, with an indication of which ones have already agreed and which are tentative, and sources of funding for the speakers.
(Optional) A description of any plshared tasks associated with the workshop, and estimate of the number of participants. Having a shared task is optional.
The submission form will request information that does not factor into the decision process, but are necessary for logistical reasons:

An estimate of the maximum number of attendees at one given time
Number of estimated in-person posters
Preferred Venue (first and second preference). Providing a second preferred venue is optional, and we assume that providing a second preference indicates its compatibility for the workshop. While we will do our best to adhere to these preferences, we cannot guarantee that they will be satisfied.
Duration of the workshop (1-day / 2-day workshop)



The two pages for information about organizers, program committee, and references must include:

The names, affiliations, and email addresses of the organizers, with a brief statement (2-5 sentences) of their research interests, areas of expertise, and experience in organizing workshops and related events.
A list of Program Committee members, with an indication of which members have already agreed. Organizers should do their best to estimate the number of submissions (especially for recurring workshops) in order to (a) ensure a sufficient number of reviewers so that each paper receives 3 reviews, and (b) anticipate that no one is committed to reviewing more than 3 papers. This practice is likely to ensure on-time and thoughtful reviews.
An indication whether the workshop will consider papers submitted through ACL Rolling Review (ARR); use OpenReview as a platform (both to take papers from ARR and for their own review); or whether the workshop will only use START as a platform, and will not use ARR. In making this choice, please pay careful attention to the ARR deadlines and conference notifications.
References